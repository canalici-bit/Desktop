
import React, { useState } from 'react';
import { UserRole } from '../types';
import { ShieldCheck, Mail, Lock, ArrowRight, Github, Chrome, PawPrint } from 'lucide-react';

interface LoginProps {
  onLogin: (role: UserRole) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    // Gerçekçi bir gecikme ekleyelim
    setTimeout(() => {
      onLogin(email.includes('owner') ? UserRole.OWNER : UserRole.VETERINARIAN);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-white flex overflow-hidden font-['Plus_Jakarta_Sans']">
      {/* Sol Panel: Görsel Alan */}
      <div className="hidden lg:flex lg:w-1/2 relative bg-slate-900 overflow-hidden items-center justify-center">
        {/* Hareketli Arka Planlar */}
        <div className="absolute top-0 left-0 w-full h-full opacity-30">
          <div className="absolute -top-24 -left-24 w-[500px] h-[500px] bg-indigo-600 rounded-full blur-[120px] animate-pulse"></div>
          <div className="absolute -bottom-24 -right-24 w-[500px] h-[500px] bg-purple-600 rounded-full blur-[120px] animate-pulse animation-delay-2000"></div>
        </div>

        <div className="relative z-10 p-16 max-w-2xl animate-in fade-in slide-in-from-left duration-1000">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-16 h-16 rounded-[2rem] bg-indigo-600 flex items-center justify-center text-white shadow-2xl shadow-indigo-500/40">
              <ShieldCheck size={36} />
            </div>
            <h1 className="text-4xl font-black text-white tracking-tighter italic">Pati Koruma</h1>
          </div>
          <h2 className="text-6xl font-black text-white leading-[1.1] mb-8 tracking-tight">
            Can dostlarımız için <span className="text-indigo-400">akıllı</span> sağlık yönetimi.
          </h2>
          <p className="text-slate-400 text-xl font-medium leading-relaxed mb-12">
            ERP + CRM destekli veterinerlik yönetim sistemi ile tüm süreçlerinizi dijitalleştirin.
          </p>
          <div className="flex gap-4">
            <div className="px-6 py-3 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 flex items-center gap-3">
              <PawPrint size={20} className="text-indigo-400" />
              <span className="text-white font-bold text-sm">1.2K+ Klinik</span>
            </div>
            <div className="px-6 py-3 bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 flex items-center gap-3">
              <ShieldCheck size={20} className="text-emerald-400" />
              <span className="text-white font-bold text-sm">Uçtan Uca Şifreleme</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sağ Panel: Giriş Formu */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 md:p-16 bg-[#F8FAFC]">
        <div className="w-full max-w-md animate-in fade-in slide-in-from-right duration-1000">
          <div className="text-center mb-12 lg:hidden">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-xl mb-4">
              <ShieldCheck size={32} />
            </div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tighter">Pati Koruma</h1>
          </div>

          <div className="mb-10">
            <h3 className="text-4xl font-black text-slate-900 tracking-tight mb-3">Hoş Geldiniz</h3>
            <p className="text-slate-500 font-bold">Lütfen hesabınıza giriş yapın.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">E-posta Adresi</label>
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
                <input 
                  type="email" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@clinic.com"
                  className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none text-slate-800 font-bold transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between ml-1">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Şifre</label>
                <button type="button" className="text-xs font-bold text-indigo-600 hover:text-indigo-800">Şifremi Unuttum</button>
              </div>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
                <input 
                  type="password" 
                  required 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-600 outline-none text-slate-800 font-bold transition-all"
                />
              </div>
            </div>

            <div className="flex items-center gap-3 ml-1">
              <input type="checkbox" className="w-5 h-5 rounded-lg border-slate-200 text-indigo-600 focus:ring-indigo-500" id="remember" />
              <label htmlFor="remember" className="text-sm font-bold text-slate-600 cursor-pointer">Beni hatırla</label>
            </div>

            <button 
              type="submit" 
              disabled={isLoading}
              className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black shadow-2xl shadow-indigo-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70"
            >
              {isLoading ? (
                <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
              ) : (
                <>
                  Sisteme Giriş Yap
                  <ArrowRight size={20} />
                </>
              )}
            </button>
          </form>

          <div className="relative my-10">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-[#F8FAFC] px-4 font-black text-slate-400 tracking-widest">Veya Şununla Devam Et</span></div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-3 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-700 hover:bg-slate-50 transition-all">
              <Chrome size={20} /> Google
            </button>
            <button className="flex items-center justify-center gap-3 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-700 hover:bg-slate-50 transition-all">
              <Github size={20} /> Github
            </button>
          </div>

          <p className="text-center mt-10 text-sm font-bold text-slate-500">
            Henüz bir hesabınız yok mu? <button className="text-indigo-600 hover:text-indigo-800">Ücretsiz Deneyin</button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
