
import React, { useState, useMemo } from 'react';
import { InventoryItem } from '../types';
import { Search, Filter, Plus, Minus, AlertTriangle, PackageOpen, X, Download, MoreHorizontal } from 'lucide-react';

interface Props {
  inventory: InventoryItem[];
  updateStock: (id: string, amount: number) => void;
  onAddItem: (item: InventoryItem) => void;
}

const ITEMS_PER_PAGE = 20;

const Inventory: React.FC<Props> = ({ inventory, updateStock, onAddItem }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(ITEMS_PER_PAGE);
  const [newItem, setNewItem] = useState({ name: '', category: 'Medicine', quantity: 0, price: 0 });

  const filteredInventory = useMemo(() => {
    return inventory.filter(item => 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [inventory, searchTerm]);

  const displayedInventory = filteredInventory.slice(0, visibleCount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddItem({
      id: `i${Date.now()}`,
      name: newItem.name,
      category: newItem.category as any,
      quantity: Number(newItem.quantity),
      unit: 'adet',
      reorderLevel: 5,
      price: Number(newItem.price)
    });
    setIsModalOpen(false);
    setNewItem({ name: '', category: 'Medicine', quantity: 0, price: 0 });
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-6 duration-700">
      {/* Modals and Controls remain same... */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xl z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] w-full max-w-md shadow-2xl overflow-hidden animate-in zoom-in duration-300 ring-1 ring-slate-200">
            <div className="p-8 bg-gradient-to-r from-indigo-600 to-violet-700 text-white flex justify-between items-center">
              <div>
                <h3 className="text-2xl font-black tracking-tight">Stok Girişi</h3>
                <p className="text-indigo-100 text-xs font-bold uppercase opacity-80 mt-1">ERP Kayıt Modülü</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hover:bg-white/30 transition-all"><X size={20} /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Ürün Bilgisi</label>
                <input 
                  required 
                  value={newItem.name} 
                  onChange={e => setNewItem({...newItem, name: e.target.value})} 
                  className="w-full p-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 text-slate-800 font-bold outline-none" 
                  placeholder="İlaç, aşı veya ekipman adı"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Miktar</label>
                  <input type="number" required value={newItem.quantity} onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 text-slate-800 font-bold outline-none" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black text-slate-400 uppercase tracking-widest ml-1">Fiyat (₺)</label>
                  <input type="number" required value={newItem.price} onChange={e => setNewItem({...newItem, price: Number(e.target.value)})} className="w-full p-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500 text-slate-800 font-bold outline-none" />
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-2xl shadow-indigo-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all">Envantere İşle</button>
            </form>
          </div>
        </div>
      )}

      {/* Kontroller */}
      <div className="bg-white p-6 rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex flex-1 items-center gap-4">
          <div className="relative w-full max-w-md group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-600 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Ürün veya kategori ara..." 
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setVisibleCount(ITEMS_PER_PAGE); // Arama değişince başa sar
              }}
              className="w-full pl-12 pr-4 py-3 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-indigo-500/20 text-slate-800 font-bold outline-none transition-all"
            />
          </div>
          <div className="text-xs font-black text-slate-400 uppercase bg-slate-50 px-4 py-3 rounded-2xl border border-slate-100">
            {filteredInventory.length} Kayıt Bulundu
          </div>
        </div>
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 px-6 py-4 text-sm font-black text-slate-600 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition-all">
            <Download size={18} /> Excel
          </button>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-3 px-8 py-4 text-sm font-black text-white rounded-2xl shadow-xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all bg-indigo-600">
            <Plus size={20} strokeWidth={3} /> Yeni Ürün Ekle
          </button>
        </div>
      </div>

      {/* Tablo */}
      <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/50 border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50 border-b border-slate-100">
              <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Ürün & Detay</th>
              <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Kategori</th>
              <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-center">Stok Durumu</th>
              <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Birim Fiyat</th>
              <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-right">İşlemler</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {displayedInventory.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50/70 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-slate-400 border border-slate-100 shadow-sm group-hover:scale-110 transition-transform">
                      <PackageOpen size={24} />
                    </div>
                    <div>
                      <p className="text-base font-black text-slate-800 leading-none mb-1">{item.name}</p>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">Seri: #{item.id.slice(-6)}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5 text-center">
                  <span className="inline-block px-3 py-1 bg-slate-100 text-slate-600 text-[10px] font-black rounded-lg uppercase tracking-widest">
                    {item.category}
                  </span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex flex-col items-center gap-1.5">
                    <div className="flex items-center gap-2">
                      <div className={`text-lg font-black ${item.quantity <= item.reorderLevel ? 'text-rose-600' : 'text-slate-800'}`}>
                        {item.quantity} <span className="text-[10px] text-slate-400 font-bold uppercase">{item.unit}</span>
                      </div>
                      {item.quantity <= item.reorderLevel && (
                        <div className="bg-rose-100 text-rose-600 p-1.5 rounded-xl animate-bounce">
                          <AlertTriangle size={14} />
                        </div>
                      )}
                    </div>
                    <div className="w-24 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                       <div className={`h-full rounded-full ${item.quantity <= item.reorderLevel ? 'bg-rose-500' : 'bg-emerald-500'}`} 
                            style={{ width: `${Math.min(100, (item.quantity / (item.reorderLevel * 4)) * 100)}%` }}></div>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5 text-right font-black text-indigo-600 text-lg">
                  ₺{item.price.toLocaleString()}
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center justify-end gap-2">
                    <div className="flex items-center bg-slate-100 p-1 rounded-xl">
                      <button onClick={() => updateStock(item.id, -1)} className="p-2 hover:bg-white hover:text-rose-600 rounded-lg transition-all text-slate-400 shadow-sm"><Minus size={16} /></button>
                      <div className="w-px h-4 bg-slate-200 mx-1"></div>
                      <button onClick={() => updateStock(item.id, 1)} className="p-2 hover:bg-white hover:text-emerald-600 rounded-lg transition-all text-slate-400 shadow-sm"><Plus size={16} /></button>
                    </div>
                    <button className="p-2 text-slate-300 hover:text-slate-600 transition-colors"><MoreHorizontal size={20}/></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {visibleCount < filteredInventory.length && (
          <div className="p-8 flex justify-center bg-slate-50/30">
            <button 
              onClick={() => setVisibleCount(prev => prev + ITEMS_PER_PAGE)}
              className="px-10 py-4 bg-white border border-slate-200 text-slate-600 font-black rounded-2xl shadow-sm hover:bg-indigo-600 hover:text-white transition-all hover:scale-105 active:scale-95"
            >
              Daha Fazla Ürün Yükle ({filteredInventory.length - visibleCount} kalan)
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Inventory;
